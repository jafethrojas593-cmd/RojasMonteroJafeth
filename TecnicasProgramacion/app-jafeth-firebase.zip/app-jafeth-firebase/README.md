# app-jafeth-firebase

Proyecto React conectado a Firebase (Tarea I).

## Instrucciones para correr
1. Clonar repo:
   ```bash
   git clone https://github.com/tu_usuario/app-jafeth-firebase.git
   cd app-jafeth-firebase

# Instalar dependencias
npm install

# Se crea un archivo llamado:
npm install

# Y lo ejecutamos con:
npm start