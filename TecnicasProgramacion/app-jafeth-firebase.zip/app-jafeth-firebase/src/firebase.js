// src/firebase.js
// Firebase v9+ (modular) - inicialización y exportación de servicios básicos

// Importar lo necesario desde el SDK modular
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

// Reemplaza estos valores por los de tu proyecto Firebase
const firebaseConfig = {
  apiKey: "TU_API_KEY_AQUI",
  authDomain: "TU_AUTH_DOMAIN_AQUI",
  projectId: "TU_PROJECT_ID_AQUI",
  storageBucket: "TU_STORAGE_BUCKET_AQUI",
  messagingSenderId: "TU_MESSAGING_SENDER_ID_AQUI",
  appId: "TU_APP_ID_AQUI",
  // measurementId: "TU_MEASUREMENT_ID_AQUI" // opcional
};

// Inicializar la app de Firebase
const app = initializeApp(firebaseConfig);

// Inicializar servicios que necesites y exportarlos
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

// Exporta objetos para usarlos en el resto de la app
export { app, auth, db, storage };
export default app;
