import { useState } from "react";
import "./App.css";

function Fila({ index, valor }) {
  return (
    <tr>
      <td style={{ border: "1px solid red" }}>{index + 1}</td>
      <td style={{ border: "1px solid red" }}>{valor}</td>
    </tr>
  );
}

function App() {
  const [inputValue, setInputValue] = useState("");
  const [historial, setHistorial] = useState([]);
  const [ultimoValor, setUltimoValor] = useState(null);

  const agregarValor = (valor) => {
    setUltimoValor(valor);
    setHistorial((prev) => [...prev, valor]);
    setInputValue("");
  };

  const manejarClick = () => {
    if (inputValue.trim() === "" || isNaN(inputValue)) {
      alert("Por favor ingresa un número válido");
      return;
    }
    agregarValor(Number(inputValue));
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>Rojas Jafeth</h1>

      <input
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        placeholder="Ingresa un número"
      />
      <button onClick={manejarClick}>Agregar</button>

      {ultimoValor !== null && <p>Último valor ingresado: {ultimoValor}</p>}

      {historial.length > 0 && (
        <table style={{ border: "2px solid red", marginTop: "10px" }}>
          <thead>
            <tr>
              <th style={{ border: "1px solid red" }}>#</th>
              <th style={{ border: "1px solid red" }}>Valor</th>
            </tr>
          </thead>
          <tbody>
            {historial.map((valor, index) => (
              <Fila key={index} index={index} valor={valor} />
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default App;
