# Trabajo Clases 5 - React
Aplicación React con input y tabla de historial de números.

## Cómo ejecutar
1. Instalar dependencias:
npm install
Copiar código

2. Ejecutar la aplicación:
npm start
Copiar código
