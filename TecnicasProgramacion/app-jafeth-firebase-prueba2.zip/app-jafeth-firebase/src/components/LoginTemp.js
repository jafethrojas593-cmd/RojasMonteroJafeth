// src/components/Login.js
import React, { useState } from "react";
import { auth } from "../firebase";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
} from "firebase/auth";

export default function Login({ onUserChange }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [modo, setModo] = useState("login"); // "login" o "register"
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      let userCredential;
      if (modo === "register") {
        userCredential = await createUserWithEmailAndPassword(auth, email, password);
      } else {
        userCredential = await signInWithEmailAndPassword(auth, email, password);
      }
      onUserChange(userCredential.user);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleSignOut() {
    await signOut(auth);
    onUserChange(null);
  }

  return (
    <div style={{ maxWidth: 400, margin: "20px auto", padding: 12, border: "1px solid #ddd", borderRadius: 8 }}>
      <h3>{modo === "login" ? "Iniciar sesión" : "Registrarse"}</h3>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: 8 }}>
          <label>Email</label><br />
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div style={{ marginBottom: 8 }}>
          <label>Contraseña</label><br />
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} />
        </div>
        {error && <p style={{ color: "red" }}>{error}</p>}
        <button type="submit" disabled={loading}>
          {loading ? "Procesando..." : (modo === "login" ? "Entrar" : "Crear cuenta")}
        </button>
      </form>

      <div style={{ marginTop: 10 }}>
        <button onClick={() => setModo(modo === "login" ? "register" : "login")} style={{ marginRight: 8 }}>
          {modo === "login" ? "Crear cuenta" : "Volver a login"}
        </button>
        <button onClick={handleSignOut}>Cerrar sesión</button>
      </div>
    </div>
  );
}
