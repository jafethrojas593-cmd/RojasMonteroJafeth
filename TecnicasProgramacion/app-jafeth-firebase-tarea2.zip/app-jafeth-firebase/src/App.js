import React, { useEffect, useState } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "./firebase";

import Login from "./components/LoginTemp.js";
import AddNote from "./components/AddNote.js";


import AddMensajeRealtime from "./components/AddMensajeRealtime";
import ListMensajesRealtime from "./components/ListMensajesRealtime";

function App() {
const [user, setUser] = useState(null);
const [checking, setChecking] = useState(true);

useEffect(() => {
const unsubscribe = onAuthStateChanged(auth, (u) => {
setUser(u || null);
setChecking(false);
});
return () => unsubscribe();
}, []);

if (checking) return <p style={{ padding: 20 }}>Comprobando autenticación...</p>;

return (
<div style={{ padding: 20 }}> <h1>app-jafeth-firebase — Realtime: ver mensajes</h1> <p>Estado: {user ? `Autenticado como ${user.email}` : "No autenticado"}</p>

```
  <Login onUserChange={setUser} />

  {user ? (
    <>
      <AddNote user={user} />
      <AddMensajeRealtime user={user} />
      <ListMensajesRealtime />

      <section style={{ marginTop: 20 }}>
        <h4>Lista de acciones</h4>
        <p>
          Revisa Firebase Console → Realtime Database →
          <code> mensajes </code>
        </p>
      </section>
    </>
  ) : (
    <p>Inicia sesión o regístrate para añadir y ver notas.</p>
  )}
</div>


);
}

export default App;
