// src/components/AddNote.js
import React, { useState } from "react";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../firebase";

function AddNote({ user }) {
  const [text, setText] = useState("");

  const handleAdd = async () => {
    if (!text.trim()) return;

    await addDoc(collection(db, "mensajes"), {
      text,
      email: user.email,
      uid: user.uid,
      createdAt: serverTimestamp(),
    });

    setText("");
  };

  return (
    <div style={{ marginTop: 20 }}>
      <h3>Agregar mensaje (Firestore)</h3>

      <input
        type="text"
        placeholder="Escribe un mensaje"
        value={text}
        onChange={(e) => setText(e.target.value)}
        style={{ padding: 6, width: 250 }}
      />

      <button onClick={handleAdd} style={{ marginLeft: 10 }}>
        Guardar
      </button>
    </div>
  );
}

export default AddNote;
