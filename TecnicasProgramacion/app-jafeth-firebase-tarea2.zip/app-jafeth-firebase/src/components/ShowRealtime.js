import { useEffect, useState } from "react";
import { rtdb } from "../firebase";
import { ref, onValue } from "firebase/database";

function ShowRealtime() {
  const [mensajes, setMensajes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const mensajesRef = ref(rtdb, "mensajes");

    const unsubscribe = onValue(mensajesRef, (snapshot) => {
      const data = snapshot.val() || {};

      // Convertir objeto a array con id incluido
      const lista = Object.entries(data).map(([id, m]) => ({
        id,
        ...m,
      }));

      setMensajes(lista);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) return <p>Cargando mensajes...</p>;

  return (
    <div style={{ marginTop: 20 }}>
      <h2>Mensajes guardados en Realtime DB</h2>

      {mensajes.length === 0 ? (
        <p>No hay mensajes guardados aún.</p>
      ) : (
        <ul>
          {mensajes.map((m) => (
            <li key={m.id} style={{ marginBottom: 10 }}>
              <strong>{m.text || m.texto || "(sin texto)"}</strong>
              <br />

              <span style={{ color: "gray" }}>
                {m.email || m.autor || "anónimo"}
              </span>
              <br />

              <small>
                {m.createdAt
                  ? new Date(m.createdAt).toLocaleString()
                  : "sin fecha"}
              </small>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default ShowRealtime;
