// src/components/ListMensajesRealtime.js
import React, { useEffect, useState } from "react";
import { getDatabase, ref, onValue } from "firebase/database";

function ListMensajesRealtime() {
  const [mensajes, setMensajes] = useState([]);

  useEffect(() => {
    const db = getDatabase();
    const mensajesRef = ref(db, "mensajes");

    const unsubscribe = onValue(mensajesRef, (snapshot) => {
      const data = snapshot.val();
      const lista = [];

      for (let id in data) {
        lista.push({
          id,
          ...data[id],
        });
      }

      // Ordenar por fecha más reciente
      lista.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

      setMensajes(lista);
    });

    return () => unsubscribe();
  }, []);

  return (
    <div style={{ marginTop: 30 }}>
      <h3>Lista de mensajes (Realtime)</h3>

      {mensajes.length === 0 && <p>No hay mensajes aún.</p>}

      <ul>
        {mensajes.map((m) => (
          <li key={m.id} style={{ marginBottom: 10 }}>
            <strong>{m.email}</strong>: {m.text}
            <br />
            <small>ID: {m.id}</small>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ListMensajesRealtime;
