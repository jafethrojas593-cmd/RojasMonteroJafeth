// src/components/AddMensajeRealtime.js
import React, { useState } from "react";
import { getDatabase, ref, push, serverTimestamp } from "firebase/database";

function AddMensajeRealtime({ user }) {
  const [text, setText] = useState("");

  const handleAdd = async () => {
    if (!text.trim()) return;

    const db = getDatabase();
    const mensajesRef = ref(db, "mensajes");

    await push(mensajesRef, {
      text,
      email: user.email,
      uid: user.uid,
      createdAt: serverTimestamp(),
    });

    setText("");
  };

  return (
    <div style={{ marginTop: 20 }}>
      <h3>Agregar mensaje (Realtime)</h3>

      <input
        type="text"
        placeholder="Escribe un mensaje"
        value={text}
        onChange={(e) => setText(e.target.value)}
        style={{ padding: 6, width: 250 }}
      />

      <button onClick={handleAdd} style={{ marginLeft: 10 }}>
        Enviar
      </button>
    </div>
  );
}

export default AddMensajeRealtime;
