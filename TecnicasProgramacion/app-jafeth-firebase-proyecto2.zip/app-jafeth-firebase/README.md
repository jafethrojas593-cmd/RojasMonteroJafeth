# app-jafeth-firebase

Proyecto React conectado a Firebase (Tarea I).

# Instalar dependencias
npm install

# Se crea un archivo llamado:
npm install

# Y lo ejecutamos con:
npm start

## Enlace publicado (Firebase Hosting)

La aplicación está desplegada en Firebase Hosting:

* Sitio público: [https://app-jafeth-firebase.web.app](https://app-jafeth-firebase.web.app)

(El enlace corresponde al despliegue de producción; si actualizas el proyecto debes volver a ejecutar `npm run build` y `firebase deploy --only hosting`).

# (1) entrar carpeta del proyecto
cd C:\ruta\a\app-jafeth-firebase

# (2) instalar cli (opcional)
npm install -g firebase-tools

# (3) iniciar sesión
firebase login

# (4) inicializar hosting (solo la primera vez)
firebase init hosting

# (5) construir app
npm run build

# (6) desplegar hosting
firebase deploy --only hosting
