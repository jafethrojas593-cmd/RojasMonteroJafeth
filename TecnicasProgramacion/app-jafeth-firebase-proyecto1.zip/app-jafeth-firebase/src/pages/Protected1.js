// src/pages/Protected1.js
import React from "react";

export default function Protected1() {
  return (
    <div style={{ padding: 20 }}>
      <h2>Ruta protegida 1</h2>
      <p>Solo puedes ver esto si estás autenticado.</p>
    </div>
  );
}
