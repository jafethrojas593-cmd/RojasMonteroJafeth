// src/pages/Protected2.js
import React from "react";

export default function Protected2() {
  return (
    <div style={{ padding: 20 }}>
      <h2>Ruta protegida 2</h2>
      <p>Otra página protegida — también solo para usuarios autenticados.</p>
    </div>
  );
}

