// src/App.js
import React, { useEffect, useState } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "./firebase";

// Componentes existentes
import Login from "./components/LoginTemp.js";
import AddNote from "./components/AddNote.js";

// NUEVO: Realtime Database
import AddNoteRealtime from "./components/AddNoteRealtime";

function App() {
  const [user, setUser] = useState(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u || null);
      setChecking(false);
    });
    return () => unsubscribe();
  }, []);

  if (checking) return <p style={{ padding: 20 }}>Comprobando autenticación...</p>;

  return (
    <div style={{ padding: 20 }}>
      <h1>app-jafeth-firebase — Prueba 2 + Proyecto I</h1>
      <p>Estado: {user ? `Autenticado como ${user.email}` : "No autenticado"}</p>

      {/* Login */}
      <Login onUserChange={setUser} />

      {/* Si el usuario está autenticado */}
      {user ? (
        <>
          {/* Firestore (Prueba 2) */}
          <AddNote user={user} />

          {/* Realtime Database (Proyecto I) */}
          <AddNoteRealtime user={user} />

          <section style={{ marginTop: 20 }}>
            <h4>Lista de acciones</h4>
            <p>
              Ahora puedes añadir notas a <b>Firestore</b> o a <b>Realtime Database</b>.<br />
              Las notas de Realtime se guardan en la rama <code>messages</code>.
            </p>
          </section>
        </>
      ) : (
        <p>Inicia sesión o regístrate para añadir notas.</p>
      )}
    </div>
  );
}

export default App;
