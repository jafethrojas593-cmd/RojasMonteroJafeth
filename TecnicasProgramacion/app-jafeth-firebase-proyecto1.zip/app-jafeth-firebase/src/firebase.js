// src/firebase.js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getDatabase } from "firebase/database"; // <- Realtime

const firebaseConfig = {
  apiKey: "AIzaSyBw6s0P6_CO5CWT_wiSa0ioju3xq705-8M",
  authDomain: "app-jafeth-firebase.firebaseapp.com",
  projectId: "app-jafeth-firebase",
  storageBucket: "app-jafeth-firebase.firebasestorage.app",
  messagingSenderId: "535429266632",
  appId: "1:535429266632:web:a6b7a80ac995c6fb1639fd",
  measurementId: "G-672EDJH17T"
};

const app = initializeApp(firebaseConfig);

const auth = getAuth(app);
const db = getFirestore(app);
const rtdb = getDatabase(app); // instancia Realtime Database

export { app, auth, db, rtdb };
export default app;


