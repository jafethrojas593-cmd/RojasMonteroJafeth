// src/components/AddNote.js
import React, { useState } from "react";
import { db } from "../firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";

export default function AddNote({ user }) {
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState(null);

  async function handleAdd(e) {
    e.preventDefault();
    setMsg(null);
    if (!text.trim()) {
      setMsg({ type: "error", text: "Escribe algo primero." });
      return;
    }
    setLoading(true);
    try {
      // Colección "notes" (puedes cambiar nombre)
      const colRef = collection(db, "notes");
      await addDoc(colRef, {
        text: text.trim(),
        uid: user.uid,
        email: user.email,
        createdAt: serverTimestamp(),
      });
      setText("");
      setMsg({ type: "success", text: "Nota agregada." });
    } catch (err) {
      setMsg({ type: "error", text: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ maxWidth: 600, margin: "20px auto", padding: 12, border: "1px solid #ddd", borderRadius: 8 }}>
      <h3>Añadir nota</h3>
      <form onSubmit={handleAdd}>
        <input
          type="text"
          placeholder="Escribe una nota..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          style={{ width: "100%", marginBottom: 8 }}
        />
        <button type="submit" disabled={loading}>
          {loading ? "Guardando..." : "Guardar nota"}
        </button>
      </form>
      {msg && <p style={{ color: msg.type === "error" ? "red" : "green" }}>{msg.text}</p>}
    </div>
  );
}
