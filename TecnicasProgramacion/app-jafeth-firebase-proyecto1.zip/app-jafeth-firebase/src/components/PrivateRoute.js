// src/components/PrivateRoute.js
import React from "react";
import { Navigate } from "react-router-dom";

export default function PrivateRoute({ user, children }) {
  // Si user es null => no autenticado -> redirigir a /login
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  // Si está autenticado, renderiza children (la página protegida)
  return children;
}
