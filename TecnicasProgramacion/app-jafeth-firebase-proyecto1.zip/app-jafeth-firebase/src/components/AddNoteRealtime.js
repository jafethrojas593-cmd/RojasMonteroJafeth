// src/components/AddNoteRealtime.js
import React, { useState } from "react";
import { rtdb } from "../firebase";
import { ref, push, serverTimestamp } from "firebase/database";

export default function AddNoteRealtime({ user }) {
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState(null);

  async function handleAdd(e) {
    e.preventDefault();
    setMsg(null);

    if (!text.trim()) {
      setMsg({ type: "error", text: "Escribe algo primero." });
      return;
    }

    setLoading(true);

    try {
      // Referencia a la colección/ramificación "messages"
      const messagesRef = ref(rtdb, "messages");

      // push crea un id único y devuelve una referencia al nuevo nodo
      const newMessageRef = await push(messagesRef, {
        text: text.trim(),
        uid: user?.uid || null,
        email: user?.email || null,
        createdAt: serverTimestamp(), // marca de tiempo del servidor
      });

      // Si quieres el id auto-generado:
      const newId = newMessageRef.key;

      setText("");
      setMsg({ type: "success", text: "Mensaje guardado correctamente.", id: newId });
    } catch (err) {
      console.error("Error guardando en Realtime DB:", err);
      setMsg({ type: "error", text: "Error al guardar: " + err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ maxWidth: 640, margin: "20px auto", padding: 12, border: "1px solid #ddd", borderRadius: 8 }}>
      <h3>Añadir nota (Realtime DB)</h3>
      <form onSubmit={handleAdd}>
        <input
          type="text"
          placeholder="Escribe una nota..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          style={{ width: "100%", marginBottom: 8 }}
        />
        <button type="submit" disabled={loading}>
          {loading ? "Guardando..." : "Guardar en Realtime"}
        </button>
      </form>

      {msg && (
        <p style={{ color: msg.type === "error" ? "red" : "green", marginTop: 10 }}>
          {msg.text} {msg.id ? <><br/>ID: <code>{msg.id}</code></> : null}
        </p>
      )}

      <p style={{ marginTop: 8, fontSize: 13, color: "#666" }}>
        Nota: Los datos se guardan en la rama <code>/messages/&lt;pushId&gt;</code> de Realtime Database.
      </p>
    </div>
  );
}
