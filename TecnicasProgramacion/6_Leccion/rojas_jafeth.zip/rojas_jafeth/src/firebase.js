// src/firebase.js
import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyAx3S__3OMZdcsuKSFzIO12FKCHmXg01KA",
  authDomain: "leccion6progra.firebaseapp.com",
  projectId: "leccion6progra",
  storageBucket: "leccion6progra.firebasestorage.app",
  messagingSenderId: "53774894640",
  appId: "1:53774894640:web:34dcb2452388a8be7a8ff5",
  measurementId: "G-82SK2MVTQJ"
};

const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

export { database };