import { useState } from "react";
import { database } from "./firebase";
import { ref, push } from "firebase/database";
import "./App.css";

function App() {
  // Usamos un solo estado para el formulario
  const [form, setForm] = useState({ nombre: "", email: "" });

  const manejarChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const manejarSubmit = (e) => {
    e.preventDefault();

    const { nombre, email } = form;

    if (!nombre || !email) {
      alert("Todos los campos son obligatorios");
      return;
    }

    // Guardar en Firebase
    const usuariosRef = ref(database, "usuarios");
    push(usuariosRef, { nombre, email });

    setForm({ nombre: "", email: "" }); // Limpiar formulario
    alert("Usuario registrado exitosamente");
  };

  return (
    <div className="container">
      <h1>Registro de Usuarios</h1>
      <form onSubmit={manejarSubmit}>
        <input
          type="text"
          name="nombre"
          placeholder="Nombre"
          value={form.nombre}
          onChange={manejarChange}
        /><br/><br/>
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={manejarChange}
        /><br/><br/>
        <button type="submit">Registrar</button>
      </form>
    </div>
  );
}

export default App;
