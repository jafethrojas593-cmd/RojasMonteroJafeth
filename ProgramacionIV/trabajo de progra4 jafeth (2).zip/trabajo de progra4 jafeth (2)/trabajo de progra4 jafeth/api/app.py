from flask import Flask, jsonify

def crear_app():
    app = Flask(__name__)

    # Diccionario en memoria (base de datos simple)
    productos = {
        1: {"nombre": "Laptop", "precio": 750},
        2: {"nombre": "Mouse", "precio": 20},
        3: {"nombre": "Teclado", "precio": 35}
    }

    @app.route("/", methods=["GET"])
    def raiz():
        return "API funcionando. Usa /productos para ver los datos."

    @app.route("/productos", methods=["GET"])
    def obtener_productos():
        return jsonify(productos)

    @app.route("/productos/<int:producto_id>", methods=["GET"])
    def obtener_producto(producto_id):
        producto = productos.get(producto_id)
        if producto:
            return jsonify(producto)
        return jsonify({"error": "Producto no encontrado"}), 404

    return app


if __name__ == "__main__":
    app = crear_app()
    app.run(debug=True, port=8000)
