import threading
import requests

# URL base de la API
BASE_URL = "http://127.0.0.1:8000"

# Función que consulta todos los productos
def consultar_productos():
    response = requests.get(f"{BASE_URL}/productos")
    if response.status_code == 200:
        productos = response.json()
        print("\n[Thread] Todos los productos:")
        for id, producto in productos.items():
            print(f"ID: {id} - {producto['nombre']} - ${producto['precio']}")
    else:
        print("[Thread] Error al obtener productos")

# Función que consulta un producto por ID
def consultar_producto_id(producto_id):
    response = requests.get(f"{BASE_URL}/productos/{producto_id}")
    if response.status_code == 200:
        producto = response.json()
        print(f"\n[Thread] Producto {producto_id}: {producto['nombre']} - ${producto['precio']}")
    elif response.status_code == 404:
        print(f"\n[Thread] Producto {producto_id} no encontrado")
    else:
        print(f"\n[Thread] Error al obtener producto {producto_id}")

# Crear threads
thread1 = threading.Thread(target=consultar_productos)
thread2 = threading.Thread(target=consultar_producto_id, args=(1,))
thread3 = threading.Thread(target=consultar_producto_id, args=(2,))

# Iniciar threads
thread1.start()
thread2.start()
thread3.start()

# Esperar a que terminen
thread1.join()
thread2.join()
thread3.join()

print("\nTodas las consultas concurrentes han terminado.")
