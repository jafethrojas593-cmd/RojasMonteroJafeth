import requests

BASE_URL = "http://127.0.0.1:8000"

def obtener_todos_los_productos():
    url = f"{BASE_URL}/productos"
    response = requests.get(url)
    if response.status_code == 200:
        productos = response.json()
        print("Todos los productos:")
        for id, producto in productos.items():
            print(f"ID: {id} - Nombre: {producto['nombre']} - Precio: ${producto['precio']}")
    else:
        print("Error al obtener productos:", response.status_code)

def obtener_producto_por_id(producto_id):
    url = f"{BASE_URL}/productos/{producto_id}"
    response = requests.get(url)
    if response.status_code == 200:
        producto = response.json()
        print(f"\nProducto con ID {producto_id}:")
        print(f"Nombre: {producto['nombre']}")
        print(f"Precio: ${producto['precio']}")
    elif response.status_code == 404:
        print(f"\nProducto con ID {producto_id} no encontrado.")
    else:
        print(f"\nError al obtener producto {producto_id}: {response.status_code}")

if __name__ == "__main__":
    obtener_todos_los_productos()
    obtener_producto_por_id(1)
    obtener_producto_por_id(10)  
