# Trabajo Clases 6 - API de Juguetes

Este proyecto contiene:

- Una API REST en Flask (`api_juguetes.py`) que permite gestionar juguetes.
- Un cliente en Python (`cliente_juguetes.py`) que realiza operaciones CRUD sobre la API.

## Cómo ejecutar

1. Instalar dependencias:
pip install flask requests
Copiar código

2. Ejecutar la API:
python api_juguetes.py
Copiar código

3. En otra terminal, ejecutar el cliente:
python cliente_juguetes.py
Copiar código
