import requests

URL = "http://127.0.0.1:5000/juguetes"

def obtener_juguetes():
    r = requests.get(URL)
    print("Todos los juguetes:", r.json())

def agregar_juguete(nombre, tipo):
    r = requests.post(URL, json={"nombre": nombre, "tipo": tipo})
    print("Juguete agregado:", r.json())
    return r.json().get("id")  # opcional para usar el id luego

def actualizar_juguete(id_juguete, nuevos_datos):
    r = requests.put(f"{URL}/{id_juguete}", json=nuevos_datos)
    print("Juguete actualizado:", r.json())

def eliminar_juguete(id_juguete):
    r = requests.delete(f"{URL}/{id_juguete}")
    print("Eliminar juguete:", r.json())

# --- Ejecución de las operaciones ---
obtener_juguetes()
nuevo_id = agregar_juguete("Carro", "Vehículo")
actualizar_juguete(nuevo_id, {"tipo": "Construcción avanzada"})
eliminar_juguete(2)
