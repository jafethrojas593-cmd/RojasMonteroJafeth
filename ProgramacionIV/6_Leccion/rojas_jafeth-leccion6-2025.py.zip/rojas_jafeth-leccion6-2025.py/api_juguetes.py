from flask import Flask, jsonify, request

app = Flask(__name__)

# Datos iniciales: tres juguetes
JUGUETES = [
    {"id": 1, "nombre": "Pelota", "tipo": "Deporte"},
    {"id": 2, "nombre": "Muñeca", "tipo": "Figura"},
    {"id": 3, "nombre": "Lego", "tipo": "Construcción"},
]

# Función auxiliar para encontrar un juguete por id
def buscar_juguete(id):
    return next((j for j in JUGUETES if j["id"] == id), None)

# READ: Obtener todos los juguetes
@app.route("/juguetes", methods=["GET"])
def obtener_juguetes():
    return jsonify(JUGUETES)

# CREATE: Agregar un nuevo juguete
@app.route("/juguetes", methods=["POST"])
def agregar_juguete():
    datos = request.json
    nuevo_id = max(j["id"] for j in JUGUETES) + 1 if JUGUETES else 1
    nuevo_juguete = {"id": nuevo_id, **datos}
    JUGUETES.append(nuevo_juguete)
    return jsonify(nuevo_juguete), 201

# UPDATE: Modificar un juguete
@app.route("/juguetes/<int:id>", methods=["PUT"])
def actualizar_juguete(id):
    juguete = buscar_juguete(id)
    if juguete:
        juguete.update(request.json)
        return jsonify(juguete)
    return jsonify({"error": "Juguete no encontrado"}), 404

# DELETE: Eliminar un juguete
@app.route("/juguetes/<int:id>", methods=["DELETE"])
def eliminar_juguete(id):
    juguete = buscar_juguete(id)
    if juguete:
        JUGUETES.remove(juguete)
        return jsonify({"mensaje": "Juguete eliminado"})
    return jsonify({"error": "Juguete no encontrado"}), 404

if __name__ == "__main__":
    app.run(debug=True)
