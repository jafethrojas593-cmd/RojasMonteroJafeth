# rojas-jafeth-entrega

Aplicación en **Python** que ejecuta tareas **I/O-bound** mediante concurrencia con `ThreadPoolExecutor`.

---

# Requisitos

- Python 3.10 o superior  
- Conexión a internet (para las peticiones HTTP)

---

# Instalación

```bash
pip install requests
