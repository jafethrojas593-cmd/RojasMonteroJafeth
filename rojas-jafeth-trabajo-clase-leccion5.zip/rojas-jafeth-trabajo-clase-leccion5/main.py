import concurrent.futures
import requests
import time
from pathlib import Path

# === CONFIGURACIÓN ===
MAX_WORKERS = 5        # Número de hilos (ideal para tareas I/O-bound)
MAX_RETRIES = 3        # Reintentos por fallo
BACKOFF_FACTOR = 2     # Multiplicador de espera entre reintentos
TIMEOUT = 5            # Tiempo máximo (segundos) por petición


def leer_urls(archivo: str):
    """Lee las URLs desde un archivo de texto."""
    ruta = Path(archivo)
    if not ruta.exists():
        raise FileNotFoundError(f"No se encontró el archivo: {archivo}")
    with open(ruta, "r") as f:
        return [line.strip() for line in f if line.strip()]


def fetch_url(url: str):
    """Descarga el contenido de una URL con timeout y backoff."""
    for intento in range(1, MAX_RETRIES + 1):
        try:
            print(f"→ Intentando {url} (intento {intento})")
            response = requests.get(url, timeout=TIMEOUT)
            response.raise_for_status()
            return {"url": url, "status": response.status_code, "data": response.json()}
        except requests.RequestException as e:
            wait = BACKOFF_FACTOR ** (intento - 1)
            print(f"⚠️ Error en {url}: {e}. Reintentando en {wait}s...")
            time.sleep(wait)
    return {"url": url, "error": "No se pudo obtener respuesta después de varios intentos."}


def main():
    urls = leer_urls("data/urls.txt")

    print(f"🔹 Ejecutando con {MAX_WORKERS} hilos...")
    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        tareas = {executor.submit(fetch_url, url): url for url in urls}

        for future in concurrent.futures.as_completed(tareas):
            url = tareas[future]
            try:
                resultado = future.result()
                print(f"✅ Completado: {url}")
                print(resultado)
            except Exception as e:
                print(f"❌ Error procesando {url}: {e}")


if __name__ == "__main__":
    main()
